# 张元杰求职简历 - Overleaf 项目

## 快速开始

1. 将整个文件夹压缩为 `.zip`（或直接上传此 zip）
2. 打开 [Overleaf](https://www.overleaf.com) → New Project → Upload Project
3. **Menu → Compiler → XeLaTeX** → Recompile

## 文件结构

```
Zhang_Yuanjie_Resume/
├── main.tex              ← 简历主文件
├── README.md             ← 本说明
└── images/
    ├── photo.png         ← 一寸证件照
    ├── sjtu.png          ← 上海交通大学校徽
    └── whut.png          ← 武汉理工大学校徽
```

## 自定义

- **照片**：替换 `images/photo.png`
- **配色**：修改 `main.tex` 顶部 `\definecolor{primary}` 的 RGB 值
- **页数微调**：调整 `\setstretch{1.08}` 的数值（增大=更松，减小=更紧）
